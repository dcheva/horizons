# Hourly Income EDMC Plugin

This is a simple plugin for [EDMarketConnector](https://github.com/Marginal/EDMarketConnector/wiki), based on and adapted from the [EDMCJumpSpeed](https://github.com/inorton/EDMCJumpSpeed) plugin, so credit for most of the work done should be directed to their makers!

![In-game Screenshot](Screenshot.png)

As with other EDMC plugins, simply unzip the git directory into your plugins folder (or just place load.py inside a directory within the plugins directory) yielding something like
```
EDMarketConnector\plugins\EDMC-HourlyIncome-master\load.py
```
and restart EDMC afterwards.
