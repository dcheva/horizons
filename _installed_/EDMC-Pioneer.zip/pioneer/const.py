plugin_name = 'Pioneer'
plugin_version = '2.0.4'
db_version = 4
