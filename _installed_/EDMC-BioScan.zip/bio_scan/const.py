name = 'BioScan'
version = '2.6.5'
db_version = 4
